#!C:/Python36/python.exe

print("Content-Type: text/html")
print ("""
<html>
    <head>
        <title>CGI script ! Python</title>
    </head>
	
	<body>
	    <H1>This is my first CGI script</H1>
        Hello, world!
	</body>
</html>
"""
)