<?php

include("../system/functions.php");

$dir = basename(__DIR__); 

?>
<!doctype html>

<html>
    <?php include("../design/page_parts/head.php"); ?>
    
    <body>
        <div id="wrapper">
            <?php include(rel_path_inclusion("design/page_parts/header.php", $dir)); ?>
            <div id="content">
                <а href="../post_job/index.php" >
                    <div id="post_job">
                        Искаш да публикуваш работа?
                    </div>
                </а>
                <?php include(rel_path_inclusion("design/page_parts/footer.php", $dir)); ?>
            </div>
        </div>
    </body>
</html>