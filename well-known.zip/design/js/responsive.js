$(document).ready(function() {
    
    $(".burger-menu img").on("click", function(){
       
        $("#responsivemenu ul").toggleClass("open");
        
    });
    
});