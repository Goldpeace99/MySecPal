<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!-- Zaglavie -->
        <title><?php echo langPrint("MySecPal - моят онлайн IP помощник", "MySecPal - my online IP helper"); ?></title> 
        
        <!-- Vikane na CSS file za dizain -->
        <link rel="stylesheet" href="<?php echo rel_path("design/css/main.css" , $dir); ?>" />
        
        <script src="https://code.jquery.com/jquery-3.3.1.min.js" ></script>
        <script src="<?php echo rel_path("design/js/main.js" , $dir); ?>" ></script>     
    </head>