#!/home/bin/python
print
print("Hello!")