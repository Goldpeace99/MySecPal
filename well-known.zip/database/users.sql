CREATE TABLE users_profiles (
	ID int NOT NULL AUTO_INCREMENT,
	username varchar(55) NOT NULL,
	email varchar(255) NOT NULL,
	password varchar(55) NOT NULL,
	PRIMARY KEY (ID)
);