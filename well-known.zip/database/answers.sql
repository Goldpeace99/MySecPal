CREATE TABLE users_answers (
	ID int NOT NULL AUTO_INCREMENT,
    person VARCHAR(50) NOT NULL,
	documentation VARCHAR(255) NOT NULL,
    creditcard VARCHAR(255) NOT NULL,
	PRIMARY KEY (ID)
);